#define VERSION   "1.6.2"
#define BUILDDATE "Sun Feb 4 21:02:09 CET 2007"
