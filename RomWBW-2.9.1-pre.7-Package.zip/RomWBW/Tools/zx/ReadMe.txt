ZX Command

An adaptation of zxcc-0.5.6 by Wayne Warthen

This is simply a stripped down variant of John Elliott's zxcc package that
runs under a Windows command line (32 or 64 bit Windows).  It contains
only one command, "zx", which is generally equivalent to the original
zxcc command.

Please see http://www.seasip.info/Unix/Zxcc/ for more information on zxcc.

Refer to the zx.html document for usage information.
