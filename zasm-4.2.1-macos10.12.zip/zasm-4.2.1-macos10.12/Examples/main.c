

int c;
int d=123;
int n=0,u=0,l=0;
char const* const s = "ABCDE";
const int z = 666;

void main()
{
	int a;
	int b;

	a=100;
	b=200;
	c=a*b + (c+1)*c;
}
