include(__link__.m4)

#ifndef _MALLOC_H
#define _MALLOC_H

#include <alloc/malloc.h>

#endif
