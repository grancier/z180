include(__link__.m4)

#ifndef _COMPRESS_H
#define _COMPRESS_H

// data compression / decompression

#include <compress/aplib.h>
#include <compress/zx7.h>

#endif
