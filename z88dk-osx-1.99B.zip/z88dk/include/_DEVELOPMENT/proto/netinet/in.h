include(__link__.m4)

#ifndef _NETINET_IN_H
#define _NETINET_IN_H

#include <stdint.h>

typedef uint16_t in_port_t;
typedef uint32_t in_addr_t;

#endif
