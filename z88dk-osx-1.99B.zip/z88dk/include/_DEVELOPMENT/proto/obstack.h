include(__link__.m4)

#ifndef _OBSTACK_H
#define _OBSTACK_H

#include <alloc/obstack.h>

#endif
