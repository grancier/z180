/*
 *  dirent.h
 *  Just a placeholder for now
 *
 *	$Id: dirent.h,v 1.1 2012/04/20 15:46:39 stefano Exp $
 */

#ifndef __DIRENT_H__
#define __DIRENT_H__

#include <sys/compiler.h>

#if !defined(MAXNAMLEN)
#define MAXNAMLEN 12
#endif


#endif
