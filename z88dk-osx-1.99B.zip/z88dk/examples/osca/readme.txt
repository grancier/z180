This folder holds disk and file related examples

They were originally meant for the FLOS (that is an OS for the Old School Computer Architecture),
which eventually evolved to 'retargettable tools' when some of the OSCA APIs were rewritten for 
other platforms (in example, the CP/M).
