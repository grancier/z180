/* terminal.h

   Terminal characteristics and definitions used by display
   and string creation functions.

   Created 1.0 on Fri Apr 11 12:13:42 BST 1997 by don
*/
#define TERMWIDTH 80
#define TERMHEIGHT 40
#define TERMSIZE TERMWIDTH*TERMHEIGHT

